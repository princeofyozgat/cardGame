public interface completeCheck {
    void onCompilation();
}
