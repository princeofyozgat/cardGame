import javax.swing.*;

public class Main{

    public static void main(String[] args) {
        GeneralFrame generalFrame = new GeneralFrame("Memory Card Game");
        generalFrame.setLocationRelativeTo(null);
        generalFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}